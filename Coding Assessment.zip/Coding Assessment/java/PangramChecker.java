public class PangramChecker {
    public static boolean isPangram(String input) {
        // Convert the input to lowercase
        input = input.toLowerCase();

        // Create a boolean array to track the presence of each letter
        boolean[] alphabet = new boolean[26];

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);

            // Check if the character is a lowercase letter
            if ('a' <= c && c <= 'z') {
                alphabet[c - 'a'] = true;
            }
        }

        // Check if all letters from 'a' to 'z' are present
        for (boolean letterPresent : alphabet) {
            if (!letterPresent) {
                return false; // Not a pangram
            }
        }

        return true; // It's a pangram
    }

    public static void main(String[] args) {
        String input = "A quick brown fox jumps over the lazy dog";
        if (isPangram(input)) {
            System.out.println("It's a pangram!");
        } else {
            System.out.println("It's not a pangram.");
        }
    }
}